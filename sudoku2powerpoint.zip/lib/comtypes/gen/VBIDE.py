from comtypes.gen import _0002E157_0000_0000_C000_000000000046_0_5_3
globals().update(_0002E157_0000_0000_C000_000000000046_0_5_3.__dict__)
__name__ = 'comtypes.gen.VBIDE'