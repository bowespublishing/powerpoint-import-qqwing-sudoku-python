from comtypes.gen import _91493440_5A91_11CF_8700_00AA0060263B_0_2_12
globals().update(_91493440_5A91_11CF_8700_00AA0060263B_0_2_12.__dict__)
__name__ = 'comtypes.gen.PowerPoint'